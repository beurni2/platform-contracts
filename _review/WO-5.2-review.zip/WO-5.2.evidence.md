# WO-5.2 evidence — canon/attribution @ 034608e
PART A: /docs diff = exactly the 10 founder edits (A1-A10; A2=captured, A7=structural) + the derivation doc
PART B: v0.9.0 · snapshot+manifest regen deliberate · reference world stands
typecheck: all 5 packages Done (rc 0)
tests: contracts 84 (incl. attribution 21 + reason-enum fix) · certification 20 (chain 15/15) · ui-tokens 18 · i18n 15 · kernel-types 5
run-gates.sh: EXIT 0 — ALL GATES GREEN
cold proof: fresh --local clone 034608e · frozen install 0 · build 0 · run-gates EXIT 0
claim-state: STILL DEFERRED (no spec names the lifecycle)
