# WO-VITRINE — the storefront profile contract · REVIEW PACKET

**Tier:** 🟠 AMBER (contracts shape) · **canon v1.1.0** · impl `a7994e9` · base `origin/main` (v1.0.1 line)
**DO NOT MERGE** — merge requires the CTO's paste.

## What this is
`StorefrontSchema` gains the seven Vitrine-handoff §3.1 profile fields — **additively,
all defaulted**, so every pre-existing storefront parses unchanged. Shape only, per
the CTO's three rulings (my STOP on event payloads was sustained — the WO's payload
order reversed; `name`/`zone` divergences recorded, not "fixed").

## The seven fields (every limit = §3.1 verbatim)
| field | schema | default |
|---|---|---|
| `tagline` | `.max(40)` | `''` |
| `bio` | `.max(160)` | `''` |
| `cover` | `{status: none\|uploading\|pending\|live\|error, url?}` `.strict()` | `{status:'none'}` |
| `avatar` | `{mode: monogram\|photo, url?}` `.strict()` | `{mode:'monogram'}` |
| `theme` | closed enum `laterite\|danfani\|indigo\|foret` | `'laterite'` |
| `sections` | `≤4 × {id, name 1–20 trimmed, pids[]}` + superRefine « un pid vit dans ≤ 1 section » | `[]` |
| `featuredItems` | `z.array(IdSchema).max(2)` — the curatedItems primitive + cap | `[]` |

Ten pre-existing fields **byte-unchanged**. Events untouched (`events.ts` diff EMPTY).
"Never a sold-out item à la une" is a display rule (pin persists) — deliberately not
a schema constraint. Full grounding + the two divergences:
`docs/derivations/VITRINE-STOREFRONT.md`.

## api-surface delta (structured, real keys) — `logs/api-surface-delta.txt`
ADDED exports: `STOREFRONT_THEMES, StorefrontThemeSchema, StorefrontCoverSchema,
StorefrontAvatarSchema, StorefrontSectionSchema`. ADDED schemas: the same four.
CHANGED: `StorefrontSchema` — **+7 properties, 0 removed**. Nothing else moved.
Purely additive → **MINOR** (1.0.1 → 1.1.0, lockstep).

## Evidence
- **CI DISPATCHED AND GREEN** (`logs/ci-dispatch-green.txt`): `ci.yml` run #62 via
  `workflow_dispatch` on the branch, head = impl `a7994e9`, **conclusion SUCCESS** —
  real GitHub Actions, frozen install + build + manifest no-op + snapshot-version-bump
  companion + full gate suite. (`ci.yml` gained the one-line `workflow_dispatch:`
  trigger to make branch dispatch possible.)
- **Cold proof** (`logs/cold-clean-home-run-gates.log`): isolated HOME, `--local`
  clone @ `a7994e9`, frozen rc 0, drift @ 1.1.0, ALL GATES GREEN.
- **Tests +9 (contracts 135/135)** — defaults value-asserted on a legacy storefront;
  boundary/boundary+1 on every limit; closed sets refuse a 5th member; the
  pid-in-two-sections refusal (and same-section duplicate) proven.
- `logs/version-consistency.txt` — six packages 1.1.0, pinned 1.1.0, manifest 1.1.0.
- Fresh-context verifier verdict: `logs/verifier-verdict.md`.
