# VERIFIER BRIEF — WO-1.0 · platform-contracts v0.3.0 (mock-certification suite + 15-step chain runner)

You are a fresh-context verifier with NO memory of the build conversation. Judge the diff against ONLY the SPEC AUTHORITY and DoD below. Adversarial posture: read actual assertions; a check that cannot fail asserts nothing; run everything yourself.

## SPEC AUTHORITY

- **Contract §3 (verbatim):** "A mock is not trustworthy until it misbehaves like the real service. Every mock MUST: emit duplicates · deliver events out of order · delay events · return stale projections · simulate timeouts · simulate partial failures · reject invalid state transitions · be generated from the same contract schema as the producer." AND "Producer/consumer conformance tests run in CI. Before replacing a mock with the live sibling, both the live producer and the mock MUST pass the same conformance suite." AND "Events carry versioned envelopes (command_id, correlation_id, aggregate version, actor, server time)."
- **Contract §2.3 (the fifteen steps, verbatim):** 1. Create one supplier (manual). 2. Create one basic product, one image (premium-frame only — no cleanup), one variant. 3. Publish one supply projection. 4. Create one reseller listing. 5. Open one signed buyer link. 6. Create one immutable sandbox Quote. 7. Reserve one unit (atomic). 8. Complete one sandbox payment (hold). 9. Mark the supplier package ready (package/seal). 10. Assign one courier manually. 11. Transfer one package into courier custody (two-party, single-use code + seal). 12. Record one delivery confirmation (buyer drop code). 13. Produce one validated settlement-eligibility event. 14. Create one supplier + reseller SettlementObligation. 15. Reconcile the sandbox provider response.
- **E1 exit (Contract §1):** "the 15-step transaction completes with one correlation chain linking quote_id → reservation_id → payment_attempt_id → order_id → package_id → delivery_task_id → validation_id → settlement_obligation_id → provider_payout_id · the first mocks pass the mock-certification suite (§3) · the chain is visible on a basic dashboard."
- **Contract §6:** "One correlation chain per transaction" — the nine ids above.
- **Contract §2.2:** "'frozen-enough' = changes only by deliberate version bump propagated to all consumers."
- **WO-1.1 verifier NB-6:** the order-status five-state list enters canon: quote_issued | reserved | payment_pending | paid | confirmed. OrderSchema.status tightens from bare string to the enum. Terminal/failure states are E2's — they must NOT have been added.
- **WO-1.0 scope:** new package @platform/certification (node tooling; README must state it never enters an app's runtime graph): (a) adapter interface per E1 domain (payment-provider · eligibility · supply-projection · readiness) + executable 8-behavior checklist, per-behavior scorecard, exit non-zero if ANY behavior missing, certification = 8/8 no partial passes; (b) envelope conformance vs pinned PlatformEventSchema; (c) 15-step chain runner over pluggable adapters validating the nine-id chain, chain report as static HTML + text, exit non-zero on missing link/duplicate id/chain break; (d) bundled §3-complete reference adapters for all four domains self-testing suite + runner. Versions 0.3.0 everywhere; snapshot updated deliberately. JOURNAL re-records four deferred founder items with reasons (North Stars/prototype · D17 PERF-BUDGETS · D18 label rule · D19 coarseLocation).
- **FORBIDDEN:** touching money/secrets sources · app code or certifying shop-plus in-repo mocks from here · live network calls · weakening any §3 behavior to make certification passable · adding failure/terminal order states · shipping founder-blocked docket items.

## DoD (binary — judge each with your own runs)

1. Reference adapters certify 8/8 per domain (4 domains).
2. A deliberately deficient mock (one behavior removed) FAILS certification, exit 1.
3. Envelope conformance positive + malformed-envelope negative (missing correlation_id) fails.
4. Chain runner completes 15/15 against reference adapters, full nine-id chain, HTML report generated.
5. Broken-link negative (one id dropped) fails exit 1.
6. Order-status: a sixth status string refuses at parse (negative shown).
7. snapshot-version-bump check OK (0.2.0 → 0.3.0).
8. ALL pre-existing suites green untouched (money, secrets, copy-lint, RN-safe, shape-freeze, drift) — the diff must not touch money/secrets/copy-lint sources.
9. Typecheck clean.

## YOUR TASK

1. Read the full diff: /tmp/claude-0/-home-user/ec1e706a-04dd-546f-b722-7327c99daa2f/scratchpad/wo10-diff.txt (repo /home/user/platform-contracts, branch e1/wo-1.0, base main b076ff3).
2. Verify each DoD item by RUNNING it yourself in /home/user/platform-contracts (pnpm build / pnpm test / bash scripts/run-gates.sh / node packages/certification/dist/run-*.js / bash scripts/check-snapshot-version-bump.sh / node scripts/show-order-status-negative.mjs). Do NOT modify tracked files.
3. Check hard, beyond the DoD:
   - Each of the eight §3 behaviors is INDIVIDUALLY meaningful: for every behavior, a mock missing exactly that behavior fails certification with exactly that behavior failing (the test suite claims this — verify the assertions and run them).
   - The delay check's 2ms clock-quantization tolerance cannot mask a missing delay behavior (deficient case observes ~0ms).
   - The chain runner really validates: one correlation_id across all events, nine ids present AND pairwise distinct, step-6 Quote parses the frozen QuoteSchema AND reconciles, step-8 Order parses the five-state enum.
   - The five-state enum is exactly the NB-6 list, no terminal/failure states added anywhere.
   - No live network calls anywhere in the certification package (grep for fetch/http/net).
   - JOURNAL WO-1.0 entry figures are log-copyable against your own runs (87/87 tests, 4/4 domains, 27 events, 15/15, snapshot 91→93 exports, etc.) and the four deferrals are recorded with reasons.
4. Report: **VERDICT: PASS or FAIL**, then numbered findings, each tagged BLOCKING / NON-BLOCKING / NOTE with file:line evidence. Your report is attached verbatim to the founder whatever it says.
