# Fresh-context verifier — WO-5.8 Part F (canon v0.9.4, lockfile URL-form gate)

Fresh-context subagent, no memory of the build. Given only the WO (Part F), the
DoD, and the diff. Ran every check by its own hands. Verbatim verdict below.

---

**GUARD (step 1) — PASS.** origin/main (`640bd14`) contains `9e1a527` (v0.9.3 merge) as ancestor. `origin/main..HEAD` = exactly two commits: `b55b979` (impl) + `7138396` (journal). Branch `canon/v0.9.4`.

**Gate script correctness (step 2) — PASS.** `scripts/check-lockfile-url-form.mjs` reads the repo-root `pnpm-lock.yaml` and fails (exit 1) on any of three SSH-form patterns `[/git@[^\s/]+:/, /ssh:\/\//, /git\+ssh/]`, passes otherwise. Ran it on the real lockfile → **exit 0** ("zero SSH-form git URLs"). Independent `grep -c 'git@github.com:' pnpm-lock.yaml` → **0**. Broader `ssh://`/`git+ssh` grep → also zero.

**Non-vacuity by my OWN plant (step 3) — PASS.** I copied the unmodified gate script into a clean `$TMP/scripts/` tree and re-ran it against my own tampered lockfiles:
- clean control (no plant) → exit 0 (not vacuously failing)
- `git@github.com:` scp-form → exit 1
- `ssh://` form → exit 1
- `git+ssh` form → exit 1
- `git@gitlab.com:` non-github host → exit 1 (pattern is host-agnostic)

Shipped `show-lockfile-url-form-negative.sh` → **exit 1**, "planted 'git@github.com:' SSH URL rejected".

**Wiring (step 4) — PASS.** `run-gates.sh` lines 61–65 wire both positive (expected pass) and negative (expected fail, exit exactly 1).

**Part G NOT started (step 5) — PASS.** `git diff --name-only origin/main..HEAD` shows **no `packages/contracts/src` change**. All 14 changed files map to the allowed set: two gate scripts + run-gates wiring + JOURNAL + 6 package.json + 2 docs.manifest.json + snapshot + lockfile. Every `command_id`/`mint` string in the diff is JOURNAL prose or a pre-existing export name in the snapshot JSON — **no command_id/mint code**.

**Version bump + snapshot + tokens (step 6) — PASS.** All 6 package.json at 0.9.4 (zero `0.9.3` remaining); both docs.manifest.json bumped `packageVersion 0.9.3→0.9.4` (file hashes untouched); intra-deps + lockfile specifiers bumped (resolutions stay `link:../`, no SSH). Structural diff of `api-surface.snapshot.json`: exports 109/109 and schemas 71/71 identical — **delta = `packageVersion` ONLY**. `tokens.json` diff = **0 lines** (byte-unaltered).

**Full suite (step 7) — PASS.** `bash scripts/run-gates.sh` → **EXIT 0**, "ALL GATES GREEN". typecheck 0; mock certification **4/4 domains at 8/8**; **15-step chain 15/15**; both new lockfile gates behave; every other negative fixture fires exit 1.

### Findings

**NON-BLOCKING — shipped negative fixture is fragile to future refactors of the gate's root line.** `show-lockfile-url-form-negative.sh` re-roots the gate by `sed`-replacing the literal `join(dirname(fileURLToPath(import.meta.url)), '..')`. If that substitution ever silently misses (line 17 refactored), the copied script resolves `root` to the mktemp parent, finds no lockfile, and exits 1 via **"pnpm-lock.yaml not found"** — not via catching the plant. The harness only checks exit code == 1, so that would be a false-green that silently disarms the non-vacuity proof. It does **not** affect this slice: line 17 currently matches the sed, the fixture genuinely caught the plant this run, and I proved non-vacuity independently of the sed mechanism. Recommend hardening later (assert the failure output contains "SSH-form"/the offender), folded into a gate-hardening slice. Not a merge blocker for this AMBER in-review.

**Out-of-scope observation (not this slice):** the icon-manifest gate label says "26 icons" while output reports "29" — pre-existing, untouched by WO-5.8, noted only for completeness.

**VERDICT: PASS — BLOCKING count: 0**
