# WO-5.12 review packet — the payment-operator namespace (canon v0.9.8)

**Tier:** 🟠 AMBER (contracts shape — founder-ruled). **Impl commit:** `cfa6760`. **DO NOT MERGE.** On merge this is consumer-visible for PLATFORM (its named interim's executioner).

## The ruling (founder, 2026-07-13)
The payment-operator actor pattern is `ops:payment:*` (extending canon's
`ops:<domain>:*` convention). Break-glass issuance validates by **ALLOW-LIST**:
only an actor matching `^ops:payment:[A-Za-z0-9._:-]+$` validates; a supplier, a
dispatcher, an `ops:moderation:*`, or anything else is refused by non-match.

## What changed
- **`PaymentOperatorActorSchema`** (`packages/contracts/src/shapes/custody.ts`) — the
  ruled regex, exported (re-exported by `index.ts`'s `export *`).
- **`HandoffAuthorization.authorizedBy`** constrained to it (was the generic
  `IdSchema`). This is the **ISSUER** (« ÉMIS PAR — payment operator ») half of the
  break-glass maker-checker seam — the operator who *issues* the authorization.

## The "both halves" scoping (flagged, canon-grounded)
Canon's maker-checker seam (`ECOSYSTEM-MASTER-REFERENCE.md` §5 "Break-glass
verification"; `Sera-Build-Spec.md:115`; `components.md:161`) has two halves, two
different people: « ÉMIS PAR — payment operator » (issues) and « VÉRIFIÉ PAR —
dispatcher » (ground verification; **may not issue** — "nobody holds both halves").
The canon `HandoffAuthorization` shape carries **only the issuer identity**
(`authorizedBy`); the dispatcher's ground-verification is a separate operational act
and is **not a field on this shape**. So this slice constrains the one
operator-identity field the shape carries; it does **not** invent a dispatcher
field (that would be an unauthorized canon-shape addition, and the dispatcher is
**not** an `ops:payment:*` actor — the ruling itself lists "dispatcher" as refused).

## Audit of other operator-identity fields
- `ModerationDecision.decided_by` → already `ops:moderation:*` (WO-5.10, different
  domain). Correct to leave.
- `EventEnvelope.actor` → generic all-domain `z.string().min(1)`. Not payment-specific.
  Correct to leave.
- No other payment-operator field exists.

## Evidence in this packet
- `logs/impl-diff.txt` — the source diff.
- `logs/warm-run-gates.log` — full warm suite, `ALL GATES GREEN` (payment-operator negative fires exit 1).
- `logs/cold-clean-home-run-gates.log` — **cold proof showing its own isolation**
  (`export HOME=` ×1, `insteadof` ×2, `git clone --local` @ `ecb40e5`, frozen-install rc 0, ALL GATES GREEN).
- `logs/snapshot-delta.txt` — delta = packageVersion + one added export (`PaymentOperatorActorSchema`); nothing removed/changed; registeredSchemas identical.
- `logs/branch-log.txt` — branch history.
- `logs/verifier-verdict.md` — fresh-context verifier verdict (folded before push).

## Non-vacuous, both directions
- Unit (`shapes.test.ts`): a valid `ops:payment:*` issuer parses; `supplier:aicha`,
  `logistics-service:dispatch`, `ops:moderation:x`, empty-suffix `ops:payment:` all
  refuse (failing only on `authorizedBy`).
- Gate (`show-payment-operator-negative.mjs`, wired in `run-gates.sh`): same, against the built dist.
- Downstream fixture fixed: `shapes.test.ts` base `authorizedBy` `op_001` → `ops:payment:op1`.
  The certification 15-step chain builds **no** HandoffAuthorization (nothing to fix).

## Version / scope
0.9.7 → 0.9.8 across all packages; `docs/design/tokens.json` **untouched**; manifest +
snapshot + lockfile regenerated.
