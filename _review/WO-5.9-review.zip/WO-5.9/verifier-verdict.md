# Fresh-context verifier — WO-5.9 (canon v0.9.5, command_id mint rule)

Fresh-context subagent, no memory of the build. Given only the WO, the founder
ruling, the DoD, and the diff. Ran every check by its own hands. Verbatim below.

---

### 1. GUARD — pass
`04af4b5` (v0.9.4 merge) is ancestor of origin/main. `origin/main..HEAD` = exactly two commits: `e9f529d` (impl) + `e9e43e0` (JOURNAL). Working tree clean.

### 2. SCHEMA — pass
`CommandIdSchema = z.string().regex(UUID_V4).brand<'CommandId'>()`, `UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i` (version `4`, variant `[89ab]`). Branding confirmed in built `.d.ts`. Against the BUILT dist: accepts a real v4; **rejects** `'cmd_1'`, `''`, nil uuid, v1-shaped, v3-shaped, bad-variant. `mintCommandId()` returns a schema-accepted value; **1000 mints all distinct and all v4**.

### 3. CSPRNG + Math.random — pass
`mintCommandId` reads ambient `globalThis.crypto.randomUUID` — **no import of node `crypto`** (grep clean). `scan-rn-safe-entry.mjs` exit 0 (contracts root: 21 files, no node builtins, externals `[zod]`). No `Math.random(` CALL in code (only the JSDoc + a throw-string naming it without a paren).

### 4. THE GATE — pass, non-vacuous, robust
`check-mint-path-entropy.mjs` exit 0. Re-rooted at my own tmp copies:
- string naming Math.random, no paren → PASS (no false positive)
- real call `x = Math.random();` → FAIL exit 1, output names Math.random
- block-comment with paren → PASS (comment-stripping robust)
- mint file with no CSPRNG draw → FAIL (non-vacuity guard fires)
- new mint file `packages/app/src/offline/commandId.ts` with Math.random → CAUGHT (naming-convention discovery across packages)
`show-mint-path-entropy-negative.sh` exit 1 (asserts the sed re-root changed the gate bytes).

### 5. ENVELOPE non-change — pass, rationale sound
`EventEnvelopeSchema.command_id` still `z.string().min(1)` (events.ts:10). Confirmed by reading the id minting: the reference chain mints `cmd_chain_${seed}_s${step}_${n}` / `cmd_${domain}_${seed}_${n}` and `events-and-gates.test.ts` uses `cmd_1` — none is UUIDv4, so tightening would break the deterministic 15-step chain/HTML report + envelope tests at parse. Documented + flagged for the CTO. Correct safest-default.

### 6. SNAPSHOT — pass
Structural diff: `packageVersion 0.9.4→0.9.5`; exports ADDED (2) `CommandIdSchema` (zod-schema), `mintCommandId` (function); schemas ADDED (1) `CommandIdSchema`; **0 removed, 0 changed**. Exactly the claimed delta.

### 7. VERSION / TOKENS / FULL SUITE — pass
Version uniform `0.9.5` across all 6 package.json + intra-deps + both docs manifests + lockfile + drift args. `tokens.json` byte-unaltered (git diff empty). Full `run-gates.sh` EXIT 0, no GATE FAILED; typecheck 0; mock certification 4/4 × 8/8; chain 15/15; both mint gates behave.

### Observations (NON-BLOCKING)
- `logs/branch-log.txt` / the `_review/` packet are not in the two commits under review — the JOURNAL lists them as "Pending / next" (correct for in-review; the packet lands in its own commit).
- The cold-proof "clean HOME EXIT 0" claim I did NOT independently reproduce; I reproduced the WARM `run-gates.sh` EXIT 0 myself. Flagged honestly — a claim, not a defect. *(Builder note: the clean-HOME cold proof was run this session — `cold-clean-home-run-gates.log` in this packet.)*
- Schema is case-insensitive (accepts uppercase v4). RFC-consistent; `crypto.randomUUID` emits lowercase. Not a defect (deliberate input leniency).

**VERDICT: PASS — BLOCKING count: 0**
