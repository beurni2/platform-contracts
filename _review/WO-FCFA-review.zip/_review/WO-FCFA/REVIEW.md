# WO-FCFA — money suffix « FCFA » everywhere · REVIEW PACKET

**Tier:** 🟠 AMBER · **canon v1.0.1** · impl `e79caa8` · base `origin/main` (v1.0.0 line)
**DO NOT MERGE** — merge requires the CTO's paste. The FP app lanes pick it up at re-pin.

## The ruling
Founder (Beurni): *the money suffix is « FCFA », not « F » — everywhere, every money figure.*

## A note on process (honest record)
The first pass changed only the token + catalog and the derivation claimed those were
"the only two places." **The fresh-context verifier caught that as a false-completeness
miss** — money « F » still lived across the canon copy/specs, including the §6.1 spec
strings that then contradicted the very catalog I'd changed. This packet is the
**complete** sweep after that fix. This is exactly what the verifier is for.

## Scope — every money figure in platform-contracts
### Changed — rendered suffix + shared strings
- `money.currencySuffix` `' F'` → `' FCFA'` (Grand Teint token json + byte-mirror;
  **U+202F preserved**), the four §6.1 catalog strings, the FP `type.$note` example.
### Changed — canon copy & spec prose (every money-figure « F » → « FCFA »)
- Manifest-tracked (re-synced): `Shop-Plus-Build-Spec.md` §6.1 (now matches the catalog
  exactly), `ECOSYSTEM-MASTER-REFERENCE.md`, `Ecosystem-Engineering-Execution-Contract.md`,
  `DESIGN-LANGUAGE.md`, `GRAND-TEINT.md`.
- Design docs + E1 report: `copy.md` (deck: money-rule + every CTA/line), `components.md`
  (money-input **« FCFA » suffix** spec + refusal string), `motion.md`, `proposals.md`,
  `flows.md`, `assembly/E1-EXIT.md`.
- Diff on docs = **balanced suffix swaps** (every removed line carried a money `F`, every
  added line carries `FCFA`; no non-money `F` — grades/letters/hex — touched).
- Tests updated to assert FCFA (`tokens.test.ts`, `copy-lint.test.ts`).

### Excluded — deliberately, LISTED (not silent; CTO-overridable)
Dev-facing, not user-facing money: reconciliation-math **code comments**
(`money.test.ts` ×3, `show-reconciliation-negative.mjs` ×1) and the historical
`MASTER-REFERENCE-AUDIT.md` (rewriting its quotes falsifies the record). If the founder
means literally-every occurrence, I sweep these too — one word.

## DERIVE-OR-STOP (`docs/derivations/FCFA-SUFFIX.md`)
No `formatFcfa`/`renderAmount` in platform-contracts — the suffix here is pure data.
Per-app formatters live in the app repos (out of scope); each FP/GT lane confirms at
re-pin that its formatter reads `money.currencySuffix`, and that **Faso Premium has no
`money` group** (suffix resolves via `@platform/ui-tokens/legacy`, now FCFA).

## Version & snapshot delta (named)
PATCH, lockstep → all six + intra-deps + pinned drift + both manifests + api-surface
packageVersion → **1.0.1**; lockfile re-resolved. api-surface delta = packageVersion-only.
docs.manifest: packageVersion + the five re-synced canon-doc hashes.

## Evidence (my runs) — `logs/`
- `cold-clean-home-run-gates.log` — isolated HOME, `--local` @ `e79caa8`, frozen rc 0,
  drift @ 1.0.1, **ALL GATES GREEN**; greps its own isolation.
- `snapshot-delta.txt` · `money-before-after.txt` · `version-consistency.txt`.
- Suites: ui-tokens 19 · i18n 15 · contracts 126 · certification 20 · kernel-types 5;
  copy-lint 8 entries 0 violations.
