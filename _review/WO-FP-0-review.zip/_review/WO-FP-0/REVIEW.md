# WO-FP-0 — Faso Premium enters the token pipeline · REVIEW PACKET

**Tier:** 🟠 AMBER · **canon v1.0.0** · impl `a5333e9` · base `origin/main` `f912613`
**DO NOT MERGE** — merge requires the CTO's paste. Four app lanes gate on the release-merge sha.

---

## 1. What this is

The redesign handoff replaces Grand Teint's **visual layer**. This encodes the
handoff's shared system as **Faso Premium** (the new v2 root of `@platform/ui-tokens`)
and moves **Grand Teint** (v1) to a legacy import path, byte-verbatim, for one
transition window. Every value is transcribed **verbatim** from
`handoff_redesign/README.md § The shared system`; nothing absent from it is invented.

Full warrant: `docs/derivations/FASO-PREMIUM-TOKENS.md`.

## 2. The STOP → the four CTO rulings (encoded here)

I stopped before encoding: the WO asked for "six fp\* … cubic-bezier verbatim," but
the README names **seven** and only **two** carry a bezier. The CTO ruled:
① seven fp\* (fpFade/fpToast documented-out) · ② timing verbatim whatever its form
(bezier **or** keyword — never a fabricated bezier) · ③ fpPop = `{300,450}` +
`cubic-bezier(.2,.8,.2,1)` · ④ ranges → `{min,max}`, never collapsed. Plus **the
hierarchy law** (README defines the system; tokens encode it; prototypes are
app-local pixel-source) — recorded for the four app lanes.

## 3. Value fidelity — every group ↔ its README source

| token group | README source | notes |
|---|---|---|
| `colour.shared` (22 leaves) | § Color (shared), l.22–24 | four status pairs; **warn carries both text tones** `#5F4403`/`#7A5104` (README states both) |
| `colour.{boutik,shop,pwa,sera}` | § Accent per app + § Signature 1 (gold) | Séra: two deep tones + `tintCard` + gold `#C2571B` (woven-band "third color") |
| `type` | § Type, l.16–20 | ranges `{min,max}`; **`body` has no weight in README → none encoded**; `titleLetterSpacing` = ASCII `-.02em` (see flag) |
| `radius` | § Geometry, l.44 | `art`/`buttonSecondary` are ranges |
| `geometry` | § Geometry, l.43/46/48 | the four the WO named: status 54 · padding 20 · tabDockBlur 18 · toast 2800ms |
| `motion` (seven) | § Motion, l.50–53 + prototype grep | per rulings ②③ |

**Motion (ruling ②③), verbatim:**

| fp* | durationMs | timingFunction | source |
|---|---|---|---|
| fpIn | 320 | `cubic-bezier(.2,.8,.2,1)` | README .32s + prototype 50× |
| fpUp | 340 | `cubic-bezier(.32,.72,.25,1)` | README .34s + prototype 5× |
| fpPop | {300,450} | `cubic-bezier(.2,.8,.2,1)` | ruling ③ (usage split .3×8/.45×5/.5×3) |
| fpPulse | 1200 | `ease` | prototype `1.2s ease` |
| fpBar | 1300 | `ease-in-out` | prototype `1.3s ease-in-out` |
| fpShimmer | 1200 | `linear` | prototype `1.2s linear` |
| fpShake | 400 | `ease` | prototype `.4s ease` (Séra) |

## 4. Architecture (v2 primary · v1 legacy) & gates

- `docs/design/tokens.json` = Faso Premium; `tokens.grand-teint.json` = GT (moved verbatim).
- Root `@platform/ui-tokens` = Faso Premium (`src/faso-premium.ts`);
  `@platform/ui-tokens/legacy` = Grand Teint (`src/legacy/*`, moved verbatim).
- `token-surface.data.mjs` lists **two SURFACES**; the three token gates loop over
  both. Faso Premium is fidelity+coverage-owned (no doc-derived this wave); Grand
  Teint keeps its 11 design-dimension warrants. **Coverage meta-gate owns the new
  groups; the planted stray (stray export `icon` + stray leaf `motion.fpIn.strayLeaf`)
  fires.**
- Transition-window consumer repoints → `./legacy`: `certification/.../report-html.ts`,
  `ui-tokens/test/tokens.test.ts`, `scripts/check-icon-manifest.mjs`.

## 5. Version — platform 1.0.0 (lockstep MAJOR, machine-forced)

`scripts/check-export-maps.mjs:37` asserts every package version == root version, so
a ui-tokens MAJOR is a **platform** MAJOR; from 0.9.10 the only MAJOR is **1.0.0**.
All six package.json + intra-deps + `run-gates --pinned-version` + `docs.manifest`
(both) + api-surface snapshot packageVersion → 1.0.0; lockfile re-resolved. The
design-system `$meta.version` is a separate line: 1.0.0 GT → **2.0.0** Faso Premium.

## 6. Snapshot delta (named) — `logs/snapshot-delta.txt`

api-surface snapshot: **packageVersion 0.9.10→1.0.0 ONLY**; `exports` and `schemas`
**byte-identical** (compared on the real keys, not a vacuous key-miss) — no contracts
shape moved. docs.manifest: packageVersion only (11 hashes unchanged).

## 7. Evidence (my runs)

- `logs/cold-clean-home-run-gates.log` — cold proof: isolated HOME, `git clone --local`
  @ `a5333e9`, frozen-install rc 0, **ALL GATES GREEN**. Greps its own isolation markers.
- `logs/byte-preservation.txt` — the four Grand Teint moves are **IDENTICAL** to `f912613`.
- `logs/snapshot-delta.txt` — packageVersion-only.
- `logs/version-consistency.txt` — all six 1.0.0; pinned 1.0.0; manifest 1.0.0.
- Suites: ui-tokens 19 · contracts 126 · certification 20 · kernel-types 5 · i18n 15.

## 8. One flag for the CTO (reversible pre-merge)

`type.families.display.titleLetterSpacing` transcribes the README's typographic
**U+2212 minus** (`−.02em`) to the functional CSS value `-.02em` (ASCII). The value
is preserved; the prose glyph is normalized. Override if byte-strict.

## 9. How to review

1. Read `docs/derivations/FASO-PREMIUM-TOKENS.md` against `handoff_redesign/README.md`.
2. `node scripts/check-token-fidelity.mjs` (27 groups × 2 surfaces deep-equal).
3. `bash scripts/run-gates.sh` → ALL GATES GREEN; each negative exits 1.
4. Spot-check byte-preservation and the snapshot delta logs.
