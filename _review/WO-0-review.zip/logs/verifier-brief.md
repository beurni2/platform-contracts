# VERIFIER BRIEF — WO-0 · platform-contracts v0.1.0

You are a fresh-context verifier. You carry NO memory of the build conversation. Judge the diff below against ONLY: (1) the SPEC AUTHORITY quotes, (2) the founder ruling, (3) the DoD. Be adversarial: a passing test that asserts nothing is a lie; a claim without evidence is unverified.

## SPEC AUTHORITY (quoted, verbatim from the work order)

- **Execution Contract E0, repo topology (founder decision, locked):** "three separate app repos — `boutik-plus`, `shop-plus`, `sera` — each a per-app workspace and its own deployable, plus a fourth shared repo `platform-contracts` holding `contracts/` (shapes + events), `kernel` types, the i18n string catalog + French Voice copy-lint, and the `ui` design tokens. The apps consume `platform-contracts` as a pinned, versioned package; '§5 identical across all three specs' is thereby enforced by construction, with a CI drift-check in every app repo that fails on any divergence from the pinned canon version. Canonical `/docs` live in `platform-contracts`; each app repo carries a CI-drift-checked copy."
- **Execution Contract §3:** "Canonical shapes live only in `contracts/`; no app redefines them (CI-enforced). Events carry versioned envelopes (`command_id`, `correlation_id`, aggregate version, actor, server time)."
- **Execution Contract §2.2:** "'frozen-enough' = changes only by deliberate version bump propagated to all consumers; 'stable (thin)' = the minimal fields E1 needs are fixed, richer fields may still be added by version bump."
- **Founder ruling (2026-07-08, recorded):** canonical Quote = the Boutik+/Shop+ §5.6 shape, keeping `campaignId?`/`campaignBenefit?`; **`supplyMode`/`handlingClass`/`kittingSealId` never appear on the Quote**; those fields enter `contracts/` only by deliberate version bump behind the B+9 gate.
- **Boutik+/Shop+ Spec §5.4 (identical):** the waterfall — `productSubtotal = B + M` · `buyerTotal = B + M + D` · `sellerPlatformFee = 0.05 × B` · `sellerNet = B − C − sellerPlatformFee` · `resellerGrossEarnings = C + M` · `resellerPlatformFee = 0.20 × (C + M)` · `resellerNet = 0.80 × (C + M)` · `platformProductFeeRevenue = 0.05B + 0.20(C+M)`. **Reconciliation invariant (CI):** "`productSubtotal == sellerNet + resellerNet + platformProductFeeRevenue` AND `buyerTotal == productSubtotal + D`. Delivery is OUTSIDE both fee bases." Worked baseline: B 10,000 · C 1,000 · M 1,500 · D 1,000 → subtotal 11,500 · buyerTotal 12,500 · sellerNet 8,500 · resellerNet 2,000 · platform 1,000.
- **Canonical Quote (Boutik+ Spec §5.6, verbatim — the frozen shape):**
  ```
  Quote { id, attributionResellerId(LOCKED), paymentMode, sellerBasePrice, sellerFundedCommission, resellerMarkup,
          productSubtotal, deliveryFee, buyerTotal, amountPaidAtCheckout, amountDueAtDelivery,
          sellerPlatformFee, sellerNet, resellerGrossEarnings, resellerPlatformFee, resellerNet,
          platformProductFeeRevenue, paymentProcessingFeeEstimate, taxFields,
          campaignId?, campaignBenefit?{ type, customerShare, campaignShare },
          policyVersions{settlementPolicyVersion, inspectionPolicyVersion}, expiry }        // IMMUTABLE, reconciles
  ```
- **§5.5 payment modes:** `paymentMode ∈ {FULL_PREPAY, DELIVERY_FEE_PREPAID_PRODUCT_AT_DOOR}`. FULL_PREPAY: `amountPaidAtCheckout = buyerTotal`, `amountDueAtDelivery = 0`. Option B: `amountPaidAtCheckout = D`, `amountDueAtDelivery = productSubtotal`.
- **Four secrets (§5.6, all specs):** "`sellerReadinessChallenge` (short-TTL, in-app, seller↔readiness) · `pickupVerificationCode` (rider↔pickup) · `buyerDropCode` (buyer↔delivery, private — never shown to the seller or in readiness evidence) · `HandoffAuthorization` (payment-confirmed handoff)" — CI-enforced separation; branded types not mutually assignable, not aliasable to plain string in public APIs.
- **Execution Contract §10.5 (CI-checkable form):** copy-lint over the i18n catalog fails the build on: (a) banned-register tokens in customer copy (`séquestre`, `escrow`, `veuillez`, `nonobstant`, `ci-après`, `susmentionné`, + maintained administrative-formal list); (b) register-mismatch (money-tagged string containing marketing/urgency tokens; selling-tagged string containing ledger/finance jargon); (c) reading-level budget exceeded (max sentence length / syllable heuristic per screen class); (d) a Mooré/Dioula token in a `register: money` or `class: instruction` string. Every entry carries `register (money|selling|neutral)` + a screen class. Seed strings required (Shop+ §6.1): « À payer maintenant : X F » / « À payer à la livraison : Y F », the Option A/B copy, the replay line « Vous payez X F maintenant et Y F à la livraison — d'accord ? », the non-refundable-fee warning — tagged `register: money`.
- **CTO charter §5:** design tokens — "color, type scale, spacing, radius, elevation, motion" — three app themes on one family DNA: Boutik+ grounded supply-green confidence · Shop+ warm commerce energy · Séra road-and-custody clarity. Tokens only at v0.1.0; no components.
- **Event registry requirement (WO-0 §B2):** envelope `{ command_id, correlation_id, aggregateVersion, actor, serverTime, version }` + the E1-relevant union of §5.7 event names from all three specs. **Excluded (gated, version-bump only):** all `packlab.*`, `cercle.*`, `campaign.*`, `referral.*`, `review.*` names.
- **Money functions requirement (WO-0 §B2):** pure functions only, no services: `computeWaterfall(B, C, M, D, paymentMode)` → every derived Quote money field; `assertQuoteReconciles(quote)` → both identities exact to the franc; byte-stable canonical JSON serialization for Quote/Order snapshots. FORBIDDEN: defining `resellerNet`/`sellerNet` as independent multiplications (`0.80 × …`) instead of the subtraction construction.
- **OUT OF SCOPE (WO-0):** services, order state machines, Durable Objects, persistence, network code (except the lint/drift CLIs), gated objects/events (`PackProduct`, `PackComponent`, `KittingJob`, `PackLabCeilings`, `RestockDecision`, Cercle records), app code, UI components, real provider anything, publishing to a public npm registry.

## FOUNDER RULING — RoundingLaw v1 (2026-07-09, CONFIRMED — closes the ⏳)

- `sellerPlatformFee = floor(0.05 × B)` · `resellerPlatformFee = floor(0.20 × (C + M))`
- `sellerNet = B − C − sellerPlatformFee` · `resellerNet = (C + M) − resellerPlatformFee`
- `platformProductFeeRevenue = sellerPlatformFee + resellerPlatformFee`
- All Quote money fields integer FCFA. Rounding ONLY on the two fees; nets by subtraction, never independent multiplications.
- Implement as the single named module (RoundingLaw.v1) — NO marker, NO skipped tests.
- Required in the suite: property test (∀ integer FCFA inputs in realistic ranges, both identities hold exactly) · the worked baseline (10,000 / 1,000 / 1,500 / 1,000 → 11,500 · 12,500 · 8,500 · 2,000 · 1,000) · a fixed non-divisible regression asserted exactly: B=10,001 · C=333 · M=778 · D=600 → fees 500 · 222, sellerNet 9,168, resellerNet 889, platform 722, productSubtotal 10,779, buyerTotal 11,379.

## DoD (binary — judge each item)

1. Repo builds clean.
2. Every §B7 suite green with visible assertions: typecheck · unit tests · reconciliation property tests (incl. the baseline asserted literally) · shape-freeze (public API + schema snapshot; changes fail unless snapshot deliberately updated with version bump) · copy-lint on the seed catalog PLUS a negative fixture (a catalog containing « Veuillez patienter » and « séquestre » in customer copy MUST fail the lint, failing output committed as a test assertion) · secret-separation type-level test · no-gated-shapes check.
3. The negative lint fixture demonstrably fails (output attached).
4. Shape snapshot committed.
5. `/docs` + manifest committed; `drift-check` demonstrated against a sample consumer fixture (one passing run, one tampered-doc failing run).
6. RoundingLaw v1 implemented per the founder ruling above (no marker, no skipped tests, all three required test kinds present).
7. NOTE: the `v0.1.0` git tag is intentionally NOT created — the founder reserved tagging/merging to his reviewer in the session instructions. Judge versions-set-to-0.1.0 instead. Do not fail the DoD on the absent tag.

## YOUR TASK

1. Read the full diff at `/tmp/claude-0/-home-user/ec1e706a-04dd-546f-b722-7327c99daa2f/scratchpad/wo0-diff.txt` (repo at `/home/user/platform-contracts`, branch `e0/wo-0`).
2. Verify every DoD item and every SPEC AUTHORITY constraint against the diff — read the actual test assertions, not test names. Check especially: the frozen Quote field list is EXACTLY the §5.6 shape (no missing field, no extra field, gated fields rejected); nets by subtraction; fee floors in integer arithmetic; the four §10.5 lint conditions each actually implemented and each actually failing in the negative fixture; no gated shape/event exported; nothing OUT OF SCOPE was built.
3. You MAY run: `pnpm build`, `pnpm typecheck`, `pnpm test`, `bash scripts/run-gates.sh` in `/home/user/platform-contracts` to check the claims. Do NOT modify any file.
4. Report: **VERDICT: PASS or FAIL**, then a numbered list of findings, each tagged BLOCKING / NON-BLOCKING / NOTE, each with file:line evidence. Be specific and complete — your report goes verbatim to the CTO.
