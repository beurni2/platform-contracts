# WO-5.14 — Fresh-context verifier verdicts (verbatim)

Two fresh-context passes, no build memory, own tool calls. The FIRST pass FAILED (found a real miss); the fix was applied; the SECOND pass PASSED.

---

## PASS 1 — VERDICT: FAIL (the miss that shaped the fix)
The first pass found that the audit skipped `packages/kernel-types`, leaving id-class and name/display fields the ruling covers still accepting whitespace:
- **`UserIdSchema`** (`kernel-types/identity.ts`) — an id-class field — untightened: `User.id = " "`, `"\t"`, `" x"`, `"x "` all ACCEPTED. `Storefront.id` refused `" "` but `User.id` accepted it — two id-class fields on adjacent entities disagreeing.
- **`LocationSchema.zone` / `.landmark`** (`kernel-types/location.ts`) — the delivery-route display strings, `Order.dropoff.zone`/`.landmark` — untightened and accepting `" "`, contradicting the derivation doc's own conscious ruling ("a `" "`/`"\t"` zone … is invalid … on a delivery route").
- The derivation record's "every `z.string().min(1)` field" claim was false (kernel-types never covered).

Everything the first pass could check on the touched fields (primitive, regex encoding, contracts fields, tests, gate, snapshot, versions, breakage audit, scope) passed — so the fix was well-scoped.

---

## PASS 2 (re-verification at 55c7aef) — VERDICT: PASS

Re-verification of the whitespace-tightening fix at `55c7aef`. The internal inconsistency that failed the prior review is **fully resolved**. Every check held under my own tool calls.

**The #1 question — is the inconsistency gone? YES.** My independent script (built fresh against `contracts/dist/index.js`) confirms **all** of these now refuse `" "`, `"\t"`, `" x"`, `"x "`, `""`, while accepting a clean value and internal whitespace (`"Rood Woko, Ouagadougou"`, `"Chez Aïcha"`, `"a b"`): `User.id`, `User.phoneAlias.alias` (kernel-types UserId/PhoneAlias); `Order.dropoff.zone`, `Order.dropoff.landmark` (kernel-types Location); `Storefront.id`/`.name`/`.zone`/`.category` (contracts). **No** id/name/display field where a `Storefront` twin refuses `" "` but a `User`/`Order` twin accepts it. Both packages agree.

1. **No inconsistency** — verified by runtime parse against dist. PASS.
2. **Primitive layering** — `TrimmedNonEmptyString` with `/^\S([\s\S]*\S)?$/` defined in exactly ONE location (`kernel-types/src/strings.ts:18`); contracts `common.ts` imports/re-exports it and `IdSchema = TrimmedNonEmptyString`. kernel-types does NOT import contracts — no cycle. PASS.
3. **Field coverage + exemptions** — every remaining `z.string().min(1)` in both packages maps to a dispositioned EXEMPT entry (timestamps, states, versions, machine refs incl. `collectRef`/`humanReasonRef`/`MediaRef.ref`/`mimeType`, event envelope, reasons). No id/name/display field left un-dispositioned. Exemptions defensible. PASS.
4. **Breakage audit** — fixtures across all four repos; zero whitespace-only or surrounding-whitespace values on id/name/zone/category/landmark/alias fields (excluding the negative fixture). PASS.
5. **Non-vacuous gate + suite** — `show-trimmed-string-negative.mjs` exits 1, genuinely non-vacuous (clean storefront AND order must parse; 25+10 plants refused on their specific field via exact `path.join()`). Wired in `run-gates.sh:131`. Contracts suite **126/126**. Self-cert **4/4 (8/8 each)**. Chain **15/15** (proves the reference world still builds User/Order/Location). `run-gates.sh` exits 0. PASS.
6. **Snapshot delta** (`04177e2`→`55c7aef`) — packageVersion 0.9.9→0.9.10; +1 export (`TrimmedNonEmptyString`); **115 pure pattern additions** all exactly `^\S([\s\S]*\S)?$`; **0 removed, 0 value-changed**. `Storefront.name` keeps `maxLength:120` + gains pattern; `Order.dropoff.zone`/`.landmark` gain it; timestamps/`slug`/`Location.directions`/`maskedRelay` have NO pattern; `User.id`/`phoneAlias.alias` are `{}` (opaque brand-transform — behaviour-locked by tests, as the derivation doc states and my runtime test confirmed). PASS.
7. **Tokens + versions** — tokens.json diff empty; 6 package.json at 0.9.10; run-gates.sh --pinned-version 0.9.10 both lines; both docs.manifest.json 0.9.10; lockfile bumped. PASS.
8. **Scope/laws** — no retired names; scope exactly primitive + kernel-types/contracts tightening + tests + gate fixture + derivation doc + version machinery; no new enum/taxonomy; no app code. PASS.

**Non-blocking note (not a finding):** the `shapes.test.ts` Storefront on-field assertion uses `JSON.stringify(issues).toContain(field)` — marginally weaker than exact path match, but sound here (the fixture is otherwise valid so only the tampered field fails), and the gate fixture already does strict `path.join()` matching. No action required.

---

## Builder disposition
PASS 1's FAIL was correct and load-bearing — it caught a canon internal inconsistency (`User.id` accepting `" "` while `Storefront.id` refused it) that the contracts-only audit hid. Fixed by relocating the primitive to kernel-types (the base package, correct layering, single source of truth) and tightening `UserId`/`PhoneAlias`/`Location.zone`/`landmark`; the derivation record now audits BOTH packages. PASS 2 confirms the inconsistency is gone and nothing else regressed. The impl commit was amended (not pushed) to fold the fix; cold proof re-run at `55c7aef`. The non-blocking test-assertion note is acknowledged; the gate fixture's strict path match already provides the on-field guarantee.
