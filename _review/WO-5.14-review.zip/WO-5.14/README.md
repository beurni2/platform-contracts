# WO-5.14 review packet — the whitespace tightening (canon v0.9.10)

**Tier:** 🟠 AMBER (broad `contracts/` + `kernel-types/` shape tightening — founder-ruled). **Impl commit:** `55c7aef`. **DO NOT MERGE.** Consumer note: nobody chases; consumers inherit at their next natural re-pin.

> **First-pass verifier caught a real miss (fixed):** the initial cut audited only `contracts/src` and skipped `packages/kernel-types`, leaving `UserId` (id-class) and `Location.zone`/`landmark` (delivery-route display) untightened while their contracts twins were tightened — canon disagreeing with itself. Fixed by moving the `TrimmedNonEmptyString` primitive into `@platform/kernel-types` (the base package), re-exporting it from contracts, and tightening the kernel-types id/name/display fields. Re-verified fresh.

## The ruling
**Founder (Beurni, 2026-07-15):** *"whitespace-only strings are invalid on Id-class and name-class fields: canon enforces trimmed non-empty."* Closes open question **Q1** (IdSchema whitespace).

## What changed
- New canonical primitive **`TrimmedNonEmptyString`** (`shapes/common.ts`) = `z.string().min(1).regex(/^\S([\s\S]*\S)?$/, …)` — non-empty, no leading/trailing whitespace, internal whitespace preserved. Encoded as a **regex, not a `.refine`**, so the rule is JSON-Schema-representable and **drift-locks** in the shape-freeze snapshot.
- **`IdSchema = TrimmedNonEmptyString`** → every id-class field tightened by one edit.
- In `commerce.ts`: the two `name` fields (Storefront.name keeps `.max(120)`) + the `zone`/`category`/`zoneFrom`/`zoneTo`/`zones[]` display strings.

## The reading (flagged, §7)
"Trimmed non-empty" encoded as the **stricter** "equal to its trimmed form AND non-empty" — refuses both whitespace-only (`" "`, `"\t"`, `""`) AND surrounding-whitespace (`" x"`, `"x "`). Chosen because "trimmed" implies no surrounding whitespace and an untrimmed id is a latent key bug; relaxable to contains-a-non-space if the founder meant only whitespace-only. Full reasoning + per-field disposition table in `docs/derivations/WHITESPACE-TIGHTENING.md`.

## Breakage audit (done FIRST) — PROVED ZERO both directions
Grepped every consumer repo (`platform-contracts`/`boutik-plus`/`shop-plus`/`sera`) fixtures/tests for whitespace-only AND surrounding-whitespace values on these fields → **0** and **0**. No fixture breaks. No STOP.

## Disposition
- **Tightened:** id-class (IdSchema → all id fields), the two names, and zone/category/zoneFrom/zoneTo/zones[] display strings (conscious ruling).
- **Exempt (documented):** timestamps (IsoTimestampSchema — separate class, N2 governs), machine references/codes (slug/productCode/signature/…), policy versions, free-text states/reasons, and the event envelope (command_id = Q2).

## Evidence in this packet
- `logs/impl-diff.txt` — the source diff.
- `logs/warm-run-gates.log` — full warm suite, `ALL GATES GREEN` (trimmed-string negative fires exit 1).
- `logs/cold-clean-home-run-gates.log` — **cold proof showing its own isolation** (`export HOME=` ×1, `insteadof` ×2, `git clone --local` @ `e4f94e4`, frozen-install rc 0, ALL GATES GREEN).
- `logs/snapshot-delta.txt` — +1 export `TrimmedNonEmptyString`; 105 pure `pattern` additions; 0 non-additive changes.
- `logs/branch-log.txt` · `logs/verifier-verdict.md` (folded before push).

## Non-vacuous, both directions
- Unit (`shapes.test.ts`): accept 6 clean / refuse 10; the tightening reaches real `StorefrontSchema` fields (id/resellerId/name/zone/category each refuse `" "`/`"\t"`/`""` on that field); internal whitespace preserved.
- Gate (`show-trimmed-string-negative.mjs`, wired in `run-gates.sh`): clean parses; 25 plants refuse on-field. Exit 1.

## Version / scope
0.9.9 → 0.9.10. Snapshot delta = +1 export + 105 pattern-additions + packageVersion (name keeps maxLength:120; timestamps keep no pattern). `docs/design/tokens.json` untouched.
