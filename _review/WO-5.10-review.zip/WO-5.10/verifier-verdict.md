# Fresh-context verifier — WO-5.10 (canon v0.9.6, moderation decision shapes)

Fresh-context subagent, no memory of the build. Given only the WO (the ratified
set), the DoD, and the diff. Built the package fresh and parsed against the BUILT
dist. Verbatim verdict below.

---

### 1. GUARD — PASS
`origin/main` contains `2153661` (v0.9.5 merge). Branch `canon/v0.9.6`. Exactly two commits: `6537780` (impl) + `f68cee4` (JOURNAL). Working tree clean.

### 2. THE SIX CODES — PASS
`MODERATION_REASON_CODES` is exactly the six, in order, no extras/missing/typos. Built `ModerationReasonCodeSchema` accepts all six; rejects `made_up`, near-miss `authenticity`, and empty string.

### 3. SCHEMA PROPERTIES (33/33 adversarial parse checks vs built dist) — PASS
- **(a) Silent/generic rejection unrepresentable:** `{decision:'rejected'}` FAILS; `denied` FAILS; missing `decision` FAILS. Union discriminator is exactly `'approved' | 'changes_requested'`. Both valid outcomes parse.
- **(b) Reasonless rejection unrepresentable:** `changes_requested` with `reasons:[]`, missing `reasons`, and an off-enum reason all FAIL.
- **(c) No self-moderation:** `supplier:acme`, `ops:finance:x`, `moderation:x`, empty-suffix `ops:moderation:` all FAIL; `ops:moderation:desk3` PASSES. Regex anchored — `xops:moderation:d` (prefix trick) and `ops:moderation:d\n` (trailing newline) both FAIL.
- **(d) Non-vacuity:** valid `approved` (ops) and valid `changes_requested` (≥1 reason, ops) both PARSE.
- **.strict() no smuggling:** `approved` with a stray `reasons` field FAILS; stray unknown fields on both variants FAIL.

### 4. THE GATE — PASS
`node scripts/show-moderation-decision-negative.mjs` exits **1**; its logic gates on `validsOk && refusalsOk` — asserts BOTH the two valids parse AND the three malformed decisions are refused. Genuinely non-vacuous. Wired in `run-gates.sh` as `moderation-decision-negative fail`.

### 5. DERIVE-NEVER-INVENT — PASS
Each code maps to existing canon (grepped independently):
- `facts_incomplete`, `no_public_safe_proof`, `price_or_contact_in_image` ← B+I-01 (:45, "approved facts… public-safe actual-item proof… approved moderation decision") + B+I-02 (:46, "price-free and supplier-contact-free").
- `not_neutral_packaging` ← B+3 (:176, "neutral/platform packaging rule — no supplier branding/contact on the exterior") + B+I-20 (:64).
- `prohibited_or_unlaunched_category` ← B+4 (:177) + Provisional tier (:31) + electronics gate (:182).
- `authenticity_concern` ← "no unresolved moderation/authenticity concern" (:32).
- Ops-only actor ← Roles (:28, "verification/moderation operator (Ops only)… no self-moderation").
`docs/derivations/MODERATION-DECISION.md` cites all accurately.

### 6. SNAPSHOT DELTA — PASS
Delta is exactly: `packageVersion` 0.9.5→0.9.6; exports ADDED = `MODERATION_REASON_CODES` (the six-array), `ModerationDecisionSchema`, `ModerationReasonCodeSchema`; schemas ADDED = `ModerationReasonCodeSchema`, `ModerationDecisionSchema`. Nothing removed, nothing changed. Positive shape-freeze gate passed, so the snapshot reflects the real built surface.

### 7. TOKENS + VERSIONS + FULL GATES — PASS
`docs/design/tokens.json` byte-unchanged. Version uniform 0.9.6 across all 6 package.json + `@platform/*` deps + both docs manifests. `run-gates.sh` EXIT 0, "ALL GATES GREEN". Typecheck 0. Mock certification 4/4 domains × 8/8. 15-STEP CHAIN COMPLETE. Contracts vitest 9 files / 92 tests pass, incl. `test/moderation.test.ts` (5).

### Findings
- No BLOCKING findings.
- NON-BLOCKING (informational): the actor regex char class permits `:` in the suffix, so `ops:moderation:desk:3` parses — harmless, still an ops:moderation actor (hierarchical sub-id).

**VERDICT: PASS — BLOCKING count: 0**
