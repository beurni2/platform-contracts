# WO-5.11 review packet — QR-vitrine dimension primitives (canon v0.9.7)

**Tier:** 🟠 AMBER (canon docs + tokens). **Impl commit:** `63491c5`. **DO NOT MERGE** — this sha gates WO-7.2b.

## What changed
Encodes the **four QR-vitrine dimension primitives** the designer stated, into
`docs/design/tokens.json` under a new `dimension.qr` group, mirrored in the built
`@platform/ui-tokens` `dimension` export:

| token | value | source |
|---|---|---|
| `dimension.qr.quietZoneModules` | 4 | QRVitrine spec sheet (“zone de silence de 4 modules”, ISO 18004) |
| `dimension.qr.moduleMinPx` | 4 | QRVitrine spec sheet (“module 4 px (= spacing.xs …)”) |
| `dimension.qr.printModuleMinMm` | 1.0 | QRVitrine spec sheet (“plancher d’impression 1,0 mm/module”) |
| `dimension.qr.printSideMm` | 48 | QRVitrine spec sheet (“37 × 1,3 = 48 mm — scannable …”) |

**CTO amendment (2026-07-13) folded in:** the earlier fifth token `minSideDp = 148`
was **dropped** — it was the V3 worked example, and the encoder is ruled versions
1–5, so the real URL may force V4+ and a frozen 148 would put a larger QR under its
own floor. The on-screen side is now a **derivation, not a token**:
`minSidePx(version) = (modules(version) + 2×quietZoneModules) × moduleMinPx`
(V3→148, V4→164), recorded with a print-floor check in
`docs/derivations/QR-DIMENSIONS.md`.

## Gate wiring
`dimension` joins `FIDELITY_MAP` (qr leaves checked `tokens.json ⊆ built`) and
`SUPERSET_OK` (the doc-derived `controlHeightPx`/`iconSizePx` keys stay owned by
`check-design-dimensions.mjs`). The `check-token-coverage.mjs` meta-gate owns
exactly the four `dimension.qr` leaves; its negative fixture (tamper B) plants a
stray `dimension.qr` leaf and confirms rejection.

## Evidence in this packet
- `logs/impl-diff.txt` — the source diff (tokens.json, family.ts, gate wiring, derivation doc).
- `logs/warm-run-gates.log` — full warm gate suite, `ALL GATES GREEN`.
- `logs/cold-clean-home-run-gates.log` — **cold proof showing its own isolation**
  (fresh `export HOME=`, explicit proxy `insteadOf`, fresh pnpm store, `git clone
  --local` @ `63491c5`, frozen-install rc 0, all gates green). WO-7.1 evidence law:
  `export HOME=` ×1, `insteadof` ×2 present in-log.
- `logs/snapshot-delta.txt` — api-surface delta is **packageVersion only**; exports
  map byte-identical (a ui-tokens change touches no `@platform/contracts` shape).
- `logs/branch-log.txt` — the branch history (impl A on top of merged v0.9.6).
- `logs/verifier-verdict.md` — fresh-context verifier verdict (folded before push).

## Version
0.9.6 → 0.9.7 across all packages + intra-deps; docs manifest, api snapshot, and
lockfile regenerated. Lockfile URL-form gate green (zero SSH-form git URLs).
