# WO-5.13 review packet — the storefront fields (canon v0.9.9)

**Tier:** 🟠 AMBER (contracts shape — additive, by derivation). **Impl commit:** `63e9783`. **DO NOT MERGE** — OZ re-pins at SP#001-A's resume (the resume takes the current release).

## The STOP (OZ, SP#001-A)
`StorefrontSchema` existed but lacked `name`, `zone`, `category`, `createdAt`,
`updatedAt` — the fields the Seller #001 aggregate requires.

## What changed (additive)
Five fields **appended** to `StorefrontSchema` (`shapes/commerce.ts`); every
pre-existing field byte-unchanged, `.strict()` retained, `discoverable` (already a
required boolean) untouched:

| field | schema | derivation |
|---|---|---|
| `name` | `z.string().min(1).max(120)` | SP0.2 "store **name**/zone/category focus" (Building-Plan:34). `.max(120)` = boundary guard, **not** a canon value, founder-overridable. |
| `zone` | `z.string().min(1)` | SP0.2. Display string — « Rood Woko, Ouagadougou » (copy.md:157). **No zone enum** (founder decision). |
| `category` | `z.string().min(1)` | SP0.2. Display string. **No category floor/taxonomy** (open founder decision). |
| `createdAt` | `IsoTimestampSchema` | aggregate creation time (canon server-timestamp primitive). |
| `updatedAt` | `IsoTimestampSchema` | aggregate last-mutation time. |

Ownership: §5.2 "Storefront&Attribution (OWNED here) … **owns Storefront**" (Build-Spec:80-81).

## STOP-honored (not invented)
- **Zone enum / gazetteer** — founder decision; `zone` stays a free string.
- **Category taxonomy / floor** — open founder decision; `category` stays a free string.
- **Per-event payload shapes** — none exist in canon (events = `EVENT_NAMES` union +
  the single `EventEnvelopeSchema`); `storefront.created/published.v1` are names.
  Introducing storefront-only payloads = a new architecture beyond this slice's scope.
  Per the WO's "or quote what exists": no payload shape added.

## Why additive holds
Nothing constructs a `Storefront` anywhere in the repo (grep → only a doc-comment in
`quote.ts:28`; the 15-step chain builds none), so required fields break no fixture. OZ
is the one consumer and it needs these fields.

## Evidence
- `logs/impl-diff.txt` — the source diff.
- `logs/warm-run-gates.log` — full warm suite, `ALL GATES GREEN`.
- `logs/cold-clean-home-run-gates.log` — **cold proof showing its own isolation**
  (`export HOME=`×1, `insteadof`×2, `git clone --local` @ `63e9783`, frozen rc 0, ALL GATES GREEN).
- `logs/snapshot-delta.txt` — additive: only `StorefrontSchema.properties` gains the 5 keys; pre-existing props byte-unchanged; no export change; + packageVersion.
- `logs/branch-log.txt` · `logs/verifier-verdict.md`.

## Non-vacuous, both directions
`shapes.test.ts`: a full storefront parses; empty name, over-max name (121), missing
`createdAt`/`updatedAt`/`zone`/`category`, a stray field under `.strict()`, and a
missing `discoverable` (additive-integrity check) all refuse. Full suite 106/106.

## Version / scope
0.9.8 → 0.9.9; `docs/design/tokens.json` **untouched**; manifest + snapshot + lockfile regenerated.
