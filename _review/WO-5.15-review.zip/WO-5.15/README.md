# WO-5.15 review packet — the réputation law (S8, canon docs) — v0.9.10 (no bump)

**Tier:** 🟠 AMBER (small — canon docs, founder-ruled). **Impl commit:** `9fd2ccf`. **DO NOT MERGE.** Consumer note: OZ's S8 build order is written against this encoding, queued behind its spine.

## The ruling (founder, 2026-07-15)
*La réputation d'une revendeuse est **le nombre de ventes livrées** — an exact count, never a rank/score/comparison. Source: delivery-validated events attributed to her storefront. Rendered « N ventes livrées », shown from the first delivered sale (floor 1, founder-overridable), deterministic and explainable.* Closes the last GP-CANON open item (S8).

## What changed (docs only)
- **`Shop-Plus-Build-Spec.md` SP8** — the réputation law encoded.
- **`Shop-Plus-Building-Plan.md` SP6.2** and **`ECOSYSTEM-MASTER-REFERENCE.md` SP8** — the pre-ruling "sampled"/"sample size" references **reconciled** to the count law, so canon does not self-contradict (the cross-doc completeness doctrine).
- **`docs/derivations/REPUTATION-LAW.md`** — the law + the DERIVE-OR-STOP linkage + the honest envelope flag.
- **`docs.manifest.json`** (root + contracts) — re-synced (3 doc hashes; `packageVersion` stays **0.9.10**).

## DERIVE-OR-STOP — DERIVABLE, no STOP, no payload invented
The delivered-sale → reseller linkage lives entirely in existing canonical shapes:
`delivery.validated.v1` (events.ts:61) → `ValidationDecision.taskId` (custody.ts:280) →
`DeliveryTask.orderId` (logisticsTaskBase, custody.ts:51) → **`Order.resellerId`
(commerce.ts:181, LOCKED — SP-I01)** → `Storefront.resellerId` (commerce.ts:134).
> réputation(R) = |{ Order : Order.resellerId = R ∧ its delivery task reached `delivery.validated.v1` }|

**Honest flag (recorded, NOT a STOP):** the canonical `EventEnvelopeSchema` is generic
(no subject id, no per-event payload — canon has none; the `*PayloadSchema` shapes live
only in the certification harness). So the counter derives from the Order/ValidationDecision
projections, not raw envelopes. No canon payload field is proposed or invented.

## Scope / version
**No `contracts/` shape moved** → the api-surface snapshot and all package versions are
**UNCHANGED** (0.9.10); only the doc-hash manifest is re-synced. `docs/design/tokens.json`
untouched.

## Evidence in this packet
- `logs/impl-diff.txt` — the docs diff.
- `logs/warm-run-gates.log` — full warm suite, `ALL GATES GREEN`; drift-check "11 canonical docs match manifest (packageVersion 0.9.10)".
- `logs/cold-clean-home-run-gates.log` — **cold proof showing its own isolation** (`export HOME=` ×1, `insteadof` ×2, `git clone --local` @ `9fd2ccf`, frozen-install rc 0, drift-check OK, ALL GATES GREEN).
- `logs/branch-log.txt` · `logs/verifier-verdict.md` (folded before push).
