# Fresh-context verifier — WO-5.7 (canon v0.9.3)

Fresh-context subagent, no memory of the build. Given only the WO (five parts),
the DoD, and the diff. Ran every check by its own hands. Verbatim verdict below.

---

**GUARD (my run):** branch `canon/v0.9.3`, HEAD `be0eec4`, exactly two commits under review (`c5251a9` impl + `be0eec4` journal). `origin/main` contains `494748f` (v0.9.2 merge) — branch is off it. ✓ Repo left byte-clean after my adversarial dist tampering (all restored; `dist` is untracked).

### PART A — gate-coverage meta-check (named debt ①) — PASS
- `scripts/token-surface.data.mjs` is the single source. I read both value gates: `check-token-fidelity.mjs` does `import { FIDELITY_MAP as MAP }`; `check-design-dimensions.mjs` does `import { DERIVED, OWNED_GROUPS }`. **No divergent hand-copies remain.**
- All three gates pass on a from-source rebuild: fidelity 17 groups deep-equal, design-dimensions 11 tokens warranted, coverage `23 exports each owned by exactly one gate (17 fidelity · dimension · 5 structural)` (17+1+5=23, arithmetic holds).
- **Non-vacuity proven by my OWN plants (never committed):** (1) stray top-level export `strayGlyph` → coverage **exit 1**, while fidelity + design-dimensions stayed **green** — this is precisely the "silently-not-ship" hole named debt ① describes, now caught. (2) stray leaf in fidelity group `spacing` → coverage **and** fidelity fire. (3) stray leaf in the DERIVED group `dimension` → coverage **and** design-dimensions fire.
- Shipped `show-token-coverage-negative.sh` exits 1, rejecting the designer's *exact* `icon` top-level group + a `spacing.strayLeaf`.
- Refactor did not regress: both prior negative fixtures still fire (`token-fidelity-negative` exit 1 on `#C2571B→#C2571C`; `design-dimensions-negative` exit 1 on bad-value AND bad-doc). The 9 prior derived tokens are still anchored (DERIVED = 9 prior + tab + badge = 11). tokens.json still byte-checked.

### PART C — badge = 12 (computed) — PASS
- Built `dimension.iconSizePx.badge === 12`, and it is a genuine **computed** anchor: `type.scale.labelXS.size (10) × type.scale.labelXS.lh (1.2) = 12` (I read the live built leaves).
- **Tamper proof (my run):** set `labelXS.lh 1.2→1.3` in a tmp dist → gate fired `canon computes … = 13 !== 12 — derivation broken`. It is not a hardcoded 12 that coincidentally matches.
- No top-level `icon` export exists (`'icon' in module === false`) — the canon-shape conflict was correctly refused; the coverage gate guards the stray.
- Three laws present in `DESIGN-DIMENSIONS.md`: **icon+word never alone · NOT a hit target · DO NOT UPSCALE**.

### PART D — tab = 20 (derived, not STOP) — PASS
- `docs/design/components.md:74` byte-states `icon 20 + word `labelXS` (icon+word law)` — I confirmed with `grep -F` at the exact line. The DERIVED manifest anchors to this DOC, not a README. Built `tab === 20`. components.md STATES it, so deriving (not STOP) is correct per the WO rule.

### PART B — certification skew — PASS (already clean in canon; nothing to fix at source)
- Repo-wide sweep of `packages/` + `services/`: **zero `0.6.0`, zero `neutralColors`.** `report-html.ts:1` imports `{ boutikPlusTheme, sharedColour }` — both live exports. Pin is `0.9.3`; all internal `@platform` pins are `0.9.3`.
- `git log -S neutralColors` shows it was replaced at **v0.8.0 (`036a04d`)**, long before this PR. This PR's only certification change is the routine pin bump (6 lines, no `src` touch).
- **My independent judgment:** the named-debt-③ premise ("certification declares 0.6.0 / imports neutralColors") was **stale** — false at canon HEAD. Nothing remains to fix in canon; the live skew survives only in **shop-plus's own scoped v0.6.0 override**, deletable when shop-plus re-pins. DoD "certification imports no deleted symbol" is met.

### PART E — command_id mint rule — PASS (STOP-and-flag is correct)
- `packages/contracts/src/events.ts:10` constrains `command_id: z.string().min(1)` — nothing more. Sweep of `contracts/src` + `docs/` for mint/format/entropy/uuid/ulid/idempotency-key: canon requires idempotency and names the envelope field, but **no sentence states a client-mint FORMAT or ENTROPY SOURCE.** The only mint code is certification's test-only reference fixtures.
- No canon code shipped for E (`git diff` shows no `packages/contracts/src` change). Per the WO's own rule (cannot derive from a spec sentence → founder decision), **STOP-and-flag is the correct call.** The CDO recommendation (UUIDv4/ULID from a CSPRNG) is explicitly flagged as needing a founder ruling, not implemented.

### tokens.json immutability / snapshot / version / suite — PASS
- `git diff origin/main..HEAD -- docs/design/tokens.json` is **empty**. badge & tab live in `family.ts` `dimension`. The design tool's drift into *other* copies was not imported (correctly flagged as a founder ruling).
- Snapshot delta (my programmatic diff): **`packageVersion` ONLY**, `0.9.2→0.9.3`; exports + schemas byte-identical.
- Version bump uniform `0.9.3` across all 6 package.json + both docs manifests.
- **Full `bash scripts/run-gates.sh` → EXIT 0**, "ALL GATES GREEN". typecheck 0 (8/8 tasks), mocks **8/8** (4/4 domains), chain **15/15** (28 events, corr_e1demo). Packet `logs/branch-log.txt` exists **by that exact name**.

### NON-BLOCKING observations
1. "Exactly one gate" is enforced as *no-unowned-export + no-stale-owner + leaf-completeness for value exports*. Mutual-exclusion **between** the three lists is not separately asserted: an export deliberately listed in both `FIDELITY_MAP` and `STRUCTURAL_EXPORTS` would skip leaf-checking silently. Requires deliberate mis-listing, not the "forgot to register a new export" case that named debt ① targets (fully closed). Low severity.
2. Structural exports' leaves are excluded from value-checking by design. I read `themes.ts` and confirmed the themes are pure spreads of already-fidelity-checked colour groups plus canon `name` identifiers — no raw design value escapes today.
3. DoD "cold gates green": I independently ran the **warm** suite (exit 0) and a from-source ui-tokens rebuild. The cold-clone run is the builder's captured `cold-run-gates.log` (tail = "ALL GATES GREEN"), which I did not independently reproduce — not required by the task.

---

**VERDICT: PASS — BLOCKING count: 0.** (DoD fully satisfied; DO NOT MERGE — AMBER, pending founder sign-off plus two founder rulings the session correctly surfaced: (E) the command_id mint format/entropy, and which tokens.json copy is truth.)
